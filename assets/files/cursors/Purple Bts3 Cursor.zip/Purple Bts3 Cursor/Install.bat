@echo off
setlocal enabledelayedexpansion
echo =================================
echo CURSOR INSTALLER by @dota2pornfx
echo =================================
echo.

set "SCRIPT_DIR=%~dp0"
set "CURSOR_SOURCE=%SCRIPT_DIR%cursor"

echo [INFO] Looking for cursor folder at: %CURSOR_SOURCE%
if not exist "%CURSOR_SOURCE%" (
    echo [ERROR] 'cursor' folder not found next to the script!
    echo [ERROR] Expected location: %CURSOR_SOURCE%
    pause
    exit /b 1
)

echo [INFO] Searching for Dota 2 installation...
set "DOTA2_PATH="

for /f "tokens=2*" %%a in ('reg query "HKLM\SOFTWARE\WOW6432Node\Valve\Steam" /v InstallPath 2^>nul ^| find "InstallPath"') do (
    set "STEAM_PATH=%%b"
    if exist "!STEAM_PATH!\steamapps\common\dota 2 beta\game\dota\resource\cursor" (
        set "DOTA2_PATH=!STEAM_PATH!\steamapps\common\dota 2 beta\game\dota\resource\cursor"
        goto :found
    )
)

for /f "tokens=2*" %%a in ('reg query "HKLM\SOFTWARE\Valve\Steam" /v InstallPath 2^>nul ^| find "InstallPath"') do (
    set "STEAM_PATH=%%b"
    if exist "!STEAM_PATH!\steamapps\common\dota 2 beta\game\dota\resource\cursor" (
        set "DOTA2_PATH=!STEAM_PATH!\steamapps\common\dota 2 beta\game\dota\resource\cursor"
        goto :found
    )
)

for /f "tokens=2*" %%a in ('reg query "HKCU\SOFTWARE\Valve\Steam" /v InstallPath 2^>nul ^| find "InstallPath"') do (
    set "STEAM_PATH=%%b"
    if exist "!STEAM_PATH!\steamapps\common\dota 2 beta\game\dota\resource\cursor" (
        set "DOTA2_PATH=!STEAM_PATH!\steamapps\common\dota 2 beta\game\dota\resource\cursor"
        goto :found
    )
)

echo [INFO] Not found in registry. Searching all drives...
for %%d in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
    if exist "%%d:\" (
        if exist "%%d:\Program Files (x86)\Steam\steamapps\common\dota 2 beta\game\dota\resource\cursor" (
            set "DOTA2_PATH=%%d:\Program Files (x86)\Steam\steamapps\common\dota 2 beta\game\dota\resource\cursor"
            goto :found
        )
        if exist "%%d:\Program Files\Steam\steamapps\common\dota 2 beta\game\dota\resource\cursor" (
            set "DOTA2_PATH=%%d:\Program Files\Steam\steamapps\common\dota 2 beta\game\dota\resource\cursor"
            goto :found
        )
        if exist "%%d:\Steam\steamapps\common\dota 2 beta\game\dota\resource\cursor" (
            set "DOTA2_PATH=%%d:\Steam\steamapps\common\dota 2 beta\game\dota\resource\cursor"
            goto :found
        )
        if exist "%%d:\SteamLibrary\steamapps\common\dota 2 beta\game\dota\resource\cursor" (
            set "DOTA2_PATH=%%d:\SteamLibrary\steamapps\common\dota 2 beta\game\dota\resource\cursor"
            goto :found
        )
    )
)

echo.
echo ==============================================================
echo Path not found. Move the contents of the cursor folder to
echo Steam\steamapps\common\dota 2 beta\game\dota\resource\cursor
echo ==============================================================
echo.
pause
exit /b 1

:found
echo [SUCCESS] Dota2 found at: %DOTA2_PATH%

if not exist "%DOTA2_PATH%" mkdir "%DOTA2_PATH%"

echo [INFO] Copying files...
set "FILE_COUNT=0"

for %%f in ("%CURSOR_SOURCE%\*.*") do (
    copy /y "%%f" "%DOTA2_PATH%\%%~nxf" >nul 2>&1
    if !errorlevel! equ 0 (
        set /a FILE_COUNT+=1
    ) else (
        echo [WARNING] Failed to copy: %%~nxf
    )
)

echo.
echo ========================================
echo Success! Files copied to:
echo %DOTA2_PATH%
echo.
echo Cursor installation complete!
echo ========================================
echo.
pause