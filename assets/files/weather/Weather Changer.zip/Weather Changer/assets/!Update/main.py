import os
import re

def read_file(filepath):
    encodings = ['utf-8', 'windows-1251', 'cp1252', 'iso-8859-1']
    
    for encoding in encodings:
        try:
            with open(filepath, 'r', encoding=encoding) as file:
                return file.read()
        except UnicodeDecodeError:
            continue
        except FileNotFoundError:
            print(f"File not found: {filepath}")
            return None
    
    print(f"Cant read file {filepath}")
    return None

def write_file(filepath, content):
    try:
        with open(filepath, 'w', encoding='utf-8') as file:
            file.write(content)
        return True
    except Exception as e:
        print(f"Error write {filepath}: {e}")
        return False

def find_weather_block(content):
    pattern = r'\{\s*"name"\s*"Default Weather".*?\}'
    match = re.search(pattern, content, re.DOTALL)
    
    if match:
        return match.group(0)
    
    lines = content.split('\n')
    start_idx = -1
    
    for i, line in enumerate(lines):
        if 'Default Weather' in line:
            for j in range(i, -1, -1):
                if '{' in lines[j]:
                    start_idx = j
                    break
            break
    
    if start_idx == -1:
        return None
    
    brace_count = 0
    end_idx = -1
    
    for i in range(start_idx, len(lines)):
        line = lines[i]
        brace_count += line.count('{') - line.count('}')
        if brace_count == 0 and i > start_idx:
            end_idx = i
            break
    
    if end_idx != -1:
        return '\n'.join(lines[start_idx:end_idx + 1])
    
    return None

def get_weather_name_from_content(content):
    name_match = re.search(r'"name"\s*"([^"]*)"', content)
    if name_match:
        weather_name = name_match.group(1)
        if weather_name != "Default Weather":
            return weather_name.replace(' ', '_').replace('/', '_').replace('-', '_')
    return None

def main():
    items_folder = "ITEMS-HERE"
    weather_folder = "weather"
    items_file = os.path.join(items_folder, "items_game.txt")
    
    if not os.path.exists(items_file):
        print(f"File {items_file} not found!")
        return

    if not os.path.exists(weather_folder):
        print(f"Folder {weather_folder} not found!")
        return
    
    print("Reading items_game.txt...")
    original_content = read_file(items_file)
    if original_content is None:
        return

    print("Found block Default Weather...")
    default_weather_block = find_weather_block(original_content)
    if default_weather_block is None:
        print("Block Default Weather not found!")
        return
    
    print(f"Found block Default Weather:\n{default_weather_block[:100]}...")
    
    weather_files = [f for f in os.listdir(weather_folder) if f.endswith('.txt')]
    
    if not weather_files:
        print(f"No txt files found in {weather_folder} folder!")
        return
    
    print(f"Found {len(weather_files)} of weather block files:")
    
    for weather_file in weather_files:
        weather_path = os.path.join(weather_folder, weather_file)
        print(f"\nProcessing {weather_file}...")

        weather_content = read_file(weather_path)
        if weather_content is None:
            continue

        weather_name = get_weather_name_from_content(weather_content)
        if weather_name is None:
            weather_name = os.path.splitext(weather_file)[0]
        
        print(f"Weather name: {weather_name}")
        
        new_content = original_content.replace(default_weather_block, weather_content.strip())
        
        output_filename = f"items_game_{weather_name}.txt"
        output_path = output_filename
        
        counter = 1
        while os.path.exists(output_path):
            output_filename = f"items_game_{weather_name}_{counter}.txt"
            output_path = output_filename
            counter += 1
        
        if write_file(output_path, new_content):
            print(f"Created file: {output_filename}")
        else:
            print(f"File creation error: {output_filename}")
    
    print(f"\nDone! {len(weather_files)} files processed.")

if __name__ == "__main__":
    main()