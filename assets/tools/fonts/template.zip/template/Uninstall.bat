@echo off
setlocal enabledelayedexpansion
echo =================================
echo FONT UNINSTALLER by @dota2pornfx
echo =================================
echo.

set "SCRIPT_DIR=%~dp0"
set "FONTS_SOURCE=%SCRIPT_DIR%assets\default"

echo [INFO] Looking for fonts folder at: %FONTS_SOURCE%
if not exist "%FONTS_SOURCE%" (
    echo [ERROR] 'assets\default' folder not found next to the script!
    echo [ERROR] Expected location: %FONTS_SOURCE%
    pause
    exit /b 1
)

echo [INFO] Searching for Dota 2 installation...
set "FONTS_TARGET_PATH="

for /f "tokens=2*" %%a in ('reg query "HKLM\SOFTWARE\WOW6432Node\Valve\Steam" /v InstallPath 2^>nul ^| find "InstallPath"') do (
    set "STEAM_PATH=%%b"
    if exist "!STEAM_PATH!\steamapps\common\dota 2 beta\game\dota\panorama\fonts\" (
        set "FONTS_TARGET_PATH=!STEAM_PATH!\steamapps\common\dota 2 beta\game\dota\panorama\fonts"
        goto :found
    )
)

for /f "tokens=2*" %%a in ('reg query "HKLM\SOFTWARE\Valve\Steam" /v InstallPath 2^>nul ^| find "InstallPath"') do (
    set "STEAM_PATH=%%b"
    if exist "!STEAM_PATH!\steamapps\common\dota 2 beta\game\dota\panorama\fonts\" (
        set "FONTS_TARGET_PATH=!STEAM_PATH!\steamapps\common\dota 2 beta\game\dota\panorama\fonts"
        goto :found
    )
)

for /f "tokens=2*" %%a in ('reg query "HKCU\SOFTWARE\Valve\Steam" /v InstallPath 2^>nul ^| find "InstallPath"') do (
    set "STEAM_PATH=%%b"
    if exist "!STEAM_PATH!\steamapps\common\dota 2 beta\game\dota\panorama\fonts\" (
        set "FONTS_TARGET_PATH=!STEAM_PATH!\steamapps\common\dota 2 beta\game\dota\panorama\fonts"
        goto :found
    )
)

echo [INFO] Not found in registry. Searching all drives...
for %%d in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
    if exist "%%d:\" (
        if exist "%%d:\Program Files (x86)\Steam\steamapps\common\dota 2 beta\game\dota\panorama\fonts\" (
            set "FONTS_TARGET_PATH=%%d:\Program Files (x86)\Steam\steamapps\common\dota 2 beta\game\dota\panorama\fonts"
            goto :found
        )
        if exist "%%d:\Program Files\Steam\steamapps\common\dota 2 beta\game\dota\panorama\fonts\" (
            set "FONTS_TARGET_PATH=%%d:\Program Files\Steam\steamapps\common\dota 2 beta\game\dota\panorama\fonts"
            goto :found
        )
        if exist "%%d:\Steam\steamapps\common\dota 2 beta\game\dota\panorama\fonts\" (
            set "FONTS_TARGET_PATH=%%d:\Steam\steamapps\common\dota 2 beta\game\dota\panorama\fonts"
            goto :found
        )
        if exist "%%d:\SteamLibrary\steamapps\common\dota 2 beta\game\dota\panorama\fonts\" (
            set "FONTS_TARGET_PATH=%%d:\SteamLibrary\steamapps\common\dota 2 beta\game\dota\panorama\fonts"
            goto :found
        )
    )
)

echo.
echo ==============================================================
echo Path not found. Move the contents of the assets/default/ folder to
echo Steam\steamapps\common\dota 2 beta\game\dota\panorama\fonts
echo ==============================================================
echo.
pause
exit /b 1

:found
echo [SUCCESS] Dota2 fonts folder found at: %FONTS_TARGET_PATH%

if not exist "%FONTS_TARGET_PATH%" mkdir "%FONTS_TARGET_PATH%"

echo [INFO] Cleaning fonts folder...
if exist "%FONTS_TARGET_PATH%\*" (
    del /q "%FONTS_TARGET_PATH%\*.*" >nul 2>&1
    echo [INFO] All existing files removed from fonts folder.
)

echo [INFO] Copying new font files...
set "FILE_COUNT=0"

for %%f in ("%FONTS_SOURCE%\*.*") do (
    copy /y "%%f" "%FONTS_TARGET_PATH%\%%~nxf" >nul 2>&1
    if !errorlevel! equ 0 (
        echo [OK] Copied: %%~nxf
        set /a FILE_COUNT+=1
    ) else (
        echo [WARNING] Failed to copy: %%~nxf
    )
)

echo.
echo ========================================
echo Success! Files copied to:
echo %FONTS_TARGET_PATH%
echo.
echo Font restored!
echo Copied %FILE_COUNT% file(s).
echo ========================================
echo.
pause